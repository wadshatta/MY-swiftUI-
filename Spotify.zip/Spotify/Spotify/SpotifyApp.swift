//
//  SpotifyApp.swift
//  Spotify
//
//  Created by MacBook Pro on 16/04/2022.
//

import SwiftUI

@main
struct SpotifyApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
