//
//  Signin.swift
//  MyBook
//
//  Created by MacBook Pro on 12/05/2022.
//

import SwiftUI

struct Signin: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

struct Signin_Previews: PreviewProvider {
    static var previews: some View {
        Signin()
    }
}
