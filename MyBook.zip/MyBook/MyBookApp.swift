//
//  MyBookApp.swift
//  MyBook
//
//  Created by MacBook Pro on 12/05/2022.
//

import SwiftUI

@main
struct MyBookApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
